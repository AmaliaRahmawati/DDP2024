import math

# Deklarasi fUngsi modul
def tambah(bil1, bil2):
    hitung = bil1 + bil2
    print(f"hasil penjumlahan adalah {hitung}")

def kurang(bil1, bil2):
    hitung = bil1 - bil2
    print(f"hasil pengurangan adalah {hitung}")

def kali(bil1, bil2):
    hitung = bil1 * bil2
    print(f"hasil perkalian adalah {hitung}")

def bagi(bil1, bil2):
    hitung = bil1 / bil2
    print(f"hasil pembagian adalah {hitung}")

def pangkat(bil1, bil2):
    hitung = bil1 ** bil2
    print(f"hasil perpangkatan adalah {hitung}")