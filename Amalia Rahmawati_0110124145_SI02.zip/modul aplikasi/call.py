import opr

print('#### Operator  ####')
print('=== Penjumlahan ===')
opr.tambah(2, 5)

print()
print('=== Pengurangan ===')
opr.kurang(8, 3)

print()
print('=== Perkalian ===')
opr.kali(5, 5)

print()
print('=== Pembagian ===')
opr.bagi(12, 3)

print()
print('=== Perpangkatan ===')
opr.pangkat(5, 2)


print()
print()
print('#### bangun datar ####')
import bangundatar

print()
bangundatar.l_persegi(5)

print()
bangundatar.l_persegipanjang(4,6)

print()
bangundatar.l_lingkaran(7)

print()
bangundatar.l_segitiga(4, 6)

print()
bangundatar.l_jajargenjang(8, 6)



import bangunruang
print()
print()
print('#### Bangun Ruang ####')
bangunruang.luas_kubus(5)

print()
bangunruang.luas_balok(4,5,5)

print()
bangunruang.luas_tabung(7,10)

print()
bangunruang.luas_limas(8, 3, 4)

print()
bangunruang.luas_prisma_segitiga(3, 5, 12, 6)
