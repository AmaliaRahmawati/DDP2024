from bank import *
#ciptakan object
gigi = bank('001','Buffon',5000000)
cr7 = bank('007','Ronaldo',7000000)
leo = bank('010','Messi',8000000)
salah = bank('011','Mohammad Salah', 11000000)
#use member class
gigi.nabung(2000000)
leo.nabung(1000000)
cr7.tarik(2000000)
leo.tarik(6000000)
print(bank.BANK,
"\n==========================")
gigi.cetak()
cr7.cetak()
leo.cetak()
salah.cetak()
print("Jumlah Nasabah: %i orang" % bank.jmlNasabah)