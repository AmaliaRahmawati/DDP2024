class Gempa:
    def __init__(self, skala, lokasi):
        self.skala = skala
        self.lokasi = lokasi
       

    def dampak(self):
        print(f'Ada gempa baru nih di {self.lokasi}')
        print(f'Skala dari gempa ini adalah {self.skala}')
        if self.skala < 2:
            print('dampak gempa tidak berasa')
        elif self.skala >= 2 and self.skala <= 4:
            print('dampak gempa bangunan retak retak')
        elif self.skala > 4 and self.skala <= 6:
            print('dampak gempa bangunan roboh')
        elif self.skala > 6 :
            print('dampak gempa bangunan roboh dan berpotensi tsunami')
        else : 
            print('sistem tidak dapat membaca')
        
# gempa1 = Gempa()
# gempa1.dampak(5, 'jawa barat')